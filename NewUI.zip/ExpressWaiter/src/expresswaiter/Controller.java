/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package expresswaiter;

import java.util.ArrayList;

/**
 *
 * @author Y
 */
public class Controller {
	private Home home;
	private Menu menu;
	public Controller(Home h,Menu m) {
		this.home = h;
		this.menu = m;
	}
    public Home getHome() {
		return home;
	}
	public void setHome(Home home) {
		this.home = home;
	}
	public Menu getMenu() {
		return menu;
	}
	public void setMenu(Menu menu) {
		this.menu = menu;
	}
	public static void main(String[] args) {
		//test voi 3 Array List cho 3 tang
		ArrayList<Table> t = new ArrayList<Table>();
		for (int i = 0; i < 50; i++) {
			t.add(new Table());
		}
		ArrayList<Table> t_1 = new ArrayList<Table>();
		for (int i = 0; i < 30; i++) {
			t_1.add(new Table());
		}
		ArrayList<Table> t_2 = new ArrayList<Table>();
		for (int i = 0; i < 14; i++) {
			t_2.add(new Table());
		}
        Home home = new Home(t,t_1,t_2);
        Menu menu = new Menu();
        menu.AddHomeAction(home);
        home.AddMenuAction(menu);
        home.showHome();
    }
}

