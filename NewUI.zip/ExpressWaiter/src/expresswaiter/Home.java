/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package expresswaiter;

import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.util.ArrayList;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.LayoutStyle.ComponentPlacement;

/**
 *
 * @author Y
 */
@SuppressWarnings("serial")
public class Home extends javax.swing.JFrame {
	private ArrayList<Table> tables = new ArrayList<Table>();
	private ArrayList<Table> tables_floor2 = new ArrayList<Table>();
	private ArrayList<Table> tables_floor3 = new ArrayList<Table>();

	/**
	 * Creates new form Menu
	 */
	public void AddMenuAction(Menu m) {
		for (int i = 0; i < tables.size(); i++) {
			tables.get(i).addMouseListener(new MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent evt) {
					unshowHome();
					m.showMenu();
				}
			});
		}
	}

	public Home(ArrayList<Table> array,ArrayList<Table>array_2,ArrayList<Table>array_3) {
		this.tables = array;
		this.tables_floor2 = array_2;
		this.tables_floor3 = array_3;
		setResizable(false);
		initComponents();
		addStat();
		addTable(jPanel1,panel, tables);
		addTable(jPanel5,panel1,tables_floor2);
		addTable(jPanel6,panel2,tables_floor3);
		GroupLayout gl_jPanel1 = new GroupLayout(jPanel1);
		gl_jPanel1.setHorizontalGroup(
				gl_jPanel1.createParallelGroup(Alignment.LEADING).addGroup(gl_jPanel1.createSequentialGroup().addGap(45)
						.addComponent(panel, GroupLayout.DEFAULT_SIZE, 1082, Short.MAX_VALUE).addGap(45)));
		gl_jPanel1.setVerticalGroup(
				gl_jPanel1.createParallelGroup(Alignment.TRAILING).addGroup(gl_jPanel1.createSequentialGroup()
						.addGap(41).addComponent(panel, GroupLayout.DEFAULT_SIZE, 1180, Short.MAX_VALUE).addGap(45)));
		jPanel1.setLayout(gl_jPanel1);
		GroupLayout gl_jPanel2 = new GroupLayout(jPanel5);
		gl_jPanel2.setHorizontalGroup(
				gl_jPanel2.createParallelGroup(Alignment.LEADING).addGroup(gl_jPanel2.createSequentialGroup().addGap(45)
						.addComponent(panel1, GroupLayout.DEFAULT_SIZE, 1082, Short.MAX_VALUE).addGap(45)));
		gl_jPanel2.setVerticalGroup(
				gl_jPanel2.createParallelGroup(Alignment.TRAILING).addGroup(gl_jPanel2.createSequentialGroup()
						.addGap(41).addComponent(panel1, GroupLayout.DEFAULT_SIZE, 1180, Short.MAX_VALUE).addGap(45)));
		jPanel5.setLayout(gl_jPanel2);
		GroupLayout gl_jPanel3 = new GroupLayout(jPanel6);
		gl_jPanel3.setHorizontalGroup(
				gl_jPanel3.createParallelGroup(Alignment.LEADING).addGroup(gl_jPanel3.createSequentialGroup().addGap(45)
						.addComponent(panel2, GroupLayout.DEFAULT_SIZE, 1082, Short.MAX_VALUE).addGap(45)));
		gl_jPanel3.setVerticalGroup(
				gl_jPanel3.createParallelGroup(Alignment.TRAILING).addGroup(gl_jPanel3.createSequentialGroup()
						.addGap(41).addComponent(panel2, GroupLayout.DEFAULT_SIZE, 1180, Short.MAX_VALUE).addGap(45)));
		jPanel6.setLayout(gl_jPanel3);
		fullScreen();
	}

	public ArrayList<Table> getTables_floor2() {
		return tables_floor2;
	}

	public void setTables_floor2(ArrayList<Table> tables_floor2) {
		this.tables_floor2 = tables_floor2;
	}

	public ArrayList<Table> getTables_floor3() {
		return tables_floor3;
	}

	public void setTables_floor3(ArrayList<Table> tables_floor3) {
		this.tables_floor3 = tables_floor3;
	}

	public ArrayList<Table> getTables() {
		return tables;
	}

	public void setTables(ArrayList<Table> tables) {
		this.tables = tables;
	}
	//Panel j add ArrayList Table arr
	private void addTable(javax.swing.JPanel j0,javax.swing.JPanel j, ArrayList<Table> arr) {
		int row = arr.size() / 4 ;
		//Thay doi Size cua Panel
		j0.setPreferredSize(new java.awt.Dimension(804, 250 + row*220));
		//Khai bao grid Layout
		GridLayout gd = new GridLayout(0, 4, 40, 40);
		for (int i = 0; i < arr.size(); i++) {
			j.add(arr.get(i));
		}
		j.setLayout(gd);
	}

	private void addStat() {
		stat_1 = new Stat("Số bàn trống", "Lolicon", "LinhKa");

		stat_2 = new Stat("Tổng số khách", "Khách đang chờ", "Khách đang ăn");
		GroupLayout gl_jPanel3 = new GroupLayout(jPanel3);
		gl_jPanel3.setHorizontalGroup(gl_jPanel3.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_jPanel3.createSequentialGroup().addGap(100)
						.addComponent(stat_1, GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE).addGap(100))
				.addGroup(gl_jPanel3.createSequentialGroup().addGap(100)
						.addComponent(stat_2, GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE).addGap(100))
				.addComponent(jButton1, GroupLayout.DEFAULT_SIZE, 438, Short.MAX_VALUE));
		gl_jPanel3.setVerticalGroup(gl_jPanel3.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_jPanel3.createSequentialGroup().addGap(95)
						.addComponent(stat_1, GroupLayout.PREFERRED_SIZE, 308, GroupLayout.PREFERRED_SIZE).addGap(100)
						.addComponent(stat_2, GroupLayout.PREFERRED_SIZE, 308, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED, 55, Short.MAX_VALUE)
						.addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 125, GroupLayout.PREFERRED_SIZE)));
		jPanel3.setLayout(gl_jPanel3);
	}

	/**
	 * This method is called from within the constructor to initialize the form.
	 * WARNING: Do NOT modify this code. The content of this method is always
	 * regenerated by the Form Editor.
	 */
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jPanel3 = new javax.swing.JPanel();
		jButton1 = new javax.swing.JButton();
		jTabbedPane1 = new javax.swing.JTabbedPane();
		jScrollPane1 = new javax.swing.JScrollPane();
		jPanel1 = new javax.swing.JPanel();
		jScrollPane3 = new javax.swing.JScrollPane();
		jPanel6 = new javax.swing.JPanel();
		jScrollPane2 = new javax.swing.JScrollPane();
		jPanel5 = new javax.swing.JPanel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
		jPanel3.setPreferredSize(new java.awt.Dimension(400, 800));

		jButton1.setText("Refresh");

		jTabbedPane1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
		jTabbedPane1.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
		jTabbedPane1.setName(""); // NOI18N
		jTabbedPane1.setRequestFocusEnabled(false);

		jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);

		//jPanel1.setPreferredSize(new java.awt.Dimension(804, 1266));
		panel = new JPanel();
		panel1 = new JPanel();
		panel2 = new JPanel();

		jScrollPane1.setViewportView(jPanel1);

		jTabbedPane1.addTab("       Tầng 1       ", jScrollPane1);

		jScrollPane3.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

		//jPanel6.setPreferredSize(new java.awt.Dimension(804, 1266));

		javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
		jPanel6.setLayout(jPanel6Layout);
		jPanel6Layout.setHorizontalGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 804, Short.MAX_VALUE));
		jPanel6Layout.setVerticalGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 1266, Short.MAX_VALUE));

		jScrollPane3.setViewportView(jPanel6);

		jTabbedPane1.addTab("       Tầng 2      ", jScrollPane2);

		jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

		//jPanel5.setPreferredSize(new java.awt.Dimension(804, 1266));

		javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
		jPanel5.setLayout(jPanel5Layout);
		jPanel5Layout.setHorizontalGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 804, Short.MAX_VALUE));
		jPanel5Layout.setVerticalGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 1266, Short.MAX_VALUE));

		jScrollPane2.setViewportView(jPanel5);

		jTabbedPane1.addTab("       Tầng 3       ", jScrollPane3);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		layout.setHorizontalGroup(layout.createParallelGroup(Alignment.TRAILING)
				.addGroup(layout.createSequentialGroup()
						.addComponent(jTabbedPane1, GroupLayout.DEFAULT_SIZE, 1200, Short.MAX_VALUE).addGap(0)
						.addComponent(jPanel3, GroupLayout.DEFAULT_SIZE, 440, Short.MAX_VALUE)));
		layout.setVerticalGroup(layout.createParallelGroup(Alignment.LEADING)
				.addComponent(jTabbedPane1, GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
				.addComponent(jPanel3, GroupLayout.DEFAULT_SIZE, 971, Short.MAX_VALUE));

		getContentPane().setLayout(layout);

		jTabbedPane1.getAccessibleContext().setAccessibleDescription("");

		pack();
	}// </editor-fold>

	public void showHome() {
		this.setVisible(true);
	}

	public void unshowHome() {
		this.setVisible(false);
	}

	private void fullScreen() {
		setExtendedState(JFrame.MAXIMIZED_BOTH);
	}

	Stat stat_1;
	Stat stat_2;
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel3;
	private javax.swing.JPanel jPanel5;
	private javax.swing.JPanel jPanel6;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JScrollPane jScrollPane2;
	private javax.swing.JScrollPane jScrollPane3;
	private javax.swing.JTabbedPane jTabbedPane1;
	private JPanel panel;
	private JPanel panel1;
	private JPanel panel2;
}
